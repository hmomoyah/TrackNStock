(function () {
  if (!window.SS) return;
  const state = window.SchoolStock.get(), ui = window.SS;
  const form = document.getElementById("stock-in-form") || document.getElementById("stock-out-form");
  if (!form) return;
  const stockIn = form.id === "stock-in-form";
  const select = form.elements.productId;
  select.innerHTML = `<option value="">Select product</option>` + state.products.slice().sort((a, b) => a.name.localeCompare(b.name)).map(item => `<option value="${item.id}">${ui.escape(item.name)} · ${item.stock} available</option>`).join("");
  if (stockIn && form.elements.supplierId) form.elements.supplierId.innerHTML = `<option value="">Select supplier</option>` + state.suppliers.map(item => `<option value="${item.id}">${ui.escape(item.name)}</option>`).join("");
  form.elements.date.value = new Date().toISOString().slice(0, 10);
  const history = document.getElementById("stock-history");
  const drawHistory = () => {
    const records = state.history.slice().sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 10);
    history.innerHTML = records.length ? records.map(item => `<tr><td>${ui.date(item.date)}</td><td>${ui.escape(ui.product(item.productId)?.name || "Deleted product")}</td><td><span class="status ${item.type === "IN" ? "in-stock" : "low-stock"}">${item.type === "IN" ? "Stock in" : "Stock out"}</span></td><td>${item.type === "IN" ? "+" : "−"}${item.quantity}</td><td>${ui.escape(item.reference || item.reason || "—")}</td></tr>`).join("") : `<tr><td colspan="5" class="empty-state">No stock movements recorded yet.</td></tr>`;
  };
  form.addEventListener("submit", event => {
    event.preventDefault();
    const values = new FormData(form), product = ui.product(values.get("productId")), quantity = Number(values.get("quantity"));
    if (!product || !Number.isInteger(quantity) || quantity <= 0) return ui.toast("Select a product and enter a whole quantity greater than zero.", true);
    if (!stockIn && quantity > product.stock) return ui.toast(`Only ${product.stock} units of ${product.name} are available.`, true);
    product.stock += stockIn ? quantity : -quantity;
    state.history.push({ id: Date.now(), productId: product.id, type: stockIn ? "IN" : "OUT", quantity, date: values.get("date"), reason: stockIn ? (values.get("notes") || "Delivery") : values.get("reason"), reference: values.get("reference").trim(), supplierId: Number(values.get("supplierId")) || null, notes: values.get("notes") || "" });
    window.SchoolStock.save(); drawHistory(); form.reset(); form.elements.date.value = new Date().toISOString().slice(0, 10);
    select.innerHTML = `<option value="">Select product</option>` + state.products.slice().sort((a, b) => a.name.localeCompare(b.name)).map(item => `<option value="${item.id}">${ui.escape(item.name)} · ${item.stock} available</option>`).join("");
    ui.toast(`Stock ${stockIn ? "in" : "out"} recorded. ${product.name}: ${product.stock} units remaining.`);
  });
  drawHistory();
})();
