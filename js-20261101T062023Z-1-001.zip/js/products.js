(function () {
  if (!window.SS) return;
  const state = window.SchoolStock.get(), ui = window.SS;
  const table = document.getElementById("products-table");
  const search = document.getElementById("product-search");
  const categoryFilter = document.getElementById("category-filter");
  if (table) {
    categoryFilter.innerHTML += state.categories.map(item => `<option value="${item.id}">${ui.escape(item.name)}</option>`).join("");
    function draw() {
      const term = search.value.trim().toLowerCase(), category = categoryFilter.value;
      const list = state.products.filter(item => (!term || item.name.toLowerCase().includes(term) || String(item.id).includes(term))
        && (!category || String(item.categoryId) === category));
      document.getElementById("product-count").textContent = `${list.length} products`;
      table.innerHTML = list.length ? list.map(item => `<tr><td><div class="product-name"><span class="product-symbol">✎</span><span><strong>${ui.escape(item.name)}</strong><small>SS-${item.id}</small></span></div></td><td>${ui.escape(ui.category(item.categoryId))}</td><td>${ui.escape(ui.supplier(item.supplierId))}</td><td>${ui.money(item.price)}</td><td><strong>${item.stock}</strong></td><td>${item.minStock}</td><td>${ui.badge(item)}</td><td><a class="action-link" href="product-form.html?id=${item.id}">Edit</a><button class="action-link danger-link" data-delete="${item.id}">Delete</button></td></tr>`).join("") : `<tr><td colspan="8" class="empty-state">No products match your search.</td></tr>`;
    }
    search.addEventListener("input", draw); categoryFilter.addEventListener("change", draw);
    table.addEventListener("click", event => {
      const button = event.target.closest("[data-delete]"); if (!button) return;
      const product = ui.product(button.dataset.delete);
      if (confirm(`Delete “${product.name}” from the demo catalog?`)) {
        state.products = state.products.filter(item => item.id !== product.id); window.SchoolStock.save(); draw(); ui.toast("Product deleted.");
      }
    });
    draw();
  }
  const form = document.getElementById("product-form");
  if (form) {
    const id = new URLSearchParams(location.search).get("id");
    const product = id ? ui.product(id) : null;
    if (id && !product) { ui.toast("That product could not be found.", true); location.href = "products.html"; return; }
    document.getElementById("form-title").textContent = product ? "Edit product" : "Add product";
    document.getElementById("form-breadcrumb").textContent = product ? "Edit product" : "Add product";
    form.elements.categoryId.innerHTML = `<option value="">Select category</option>` + state.categories.map(item => `<option value="${item.id}">${ui.escape(item.name)}</option>`).join("");
    form.elements.supplierId.innerHTML = `<option value="">No supplier</option>` + state.suppliers.map(item => `<option value="${item.id}">${ui.escape(item.name)}</option>`).join("");
    if (product) {
      form.elements.name.value = product.name; form.elements.categoryId.value = product.categoryId;
      form.elements.supplierId.value = product.supplierId || ""; form.elements.price.value = product.price;
      form.elements.stock.value = product.stock; form.elements.minStock.value = product.minStock;
      form.elements.description.value = product.description || "";
    }
    form.addEventListener("submit", event => {
      event.preventDefault();
      const data = new FormData(form), name = data.get("name").trim(), categoryId = Number(data.get("categoryId"));
      const price = Number(data.get("price")), stock = Number(data.get("stock")), minStock = Number(data.get("minStock"));
      if (!name || !categoryId || !Number.isFinite(price) || price <= 0 || !Number.isInteger(stock) || stock < 0 || !Number.isInteger(minStock) || minStock < 0) return ui.toast("Enter a name, category, positive price, and valid whole-number stock levels.", true);
      const record = { name, categoryId, supplierId: Number(data.get("supplierId")) || null, price, stock, minStock, description: data.get("description").trim() };
      if (product) Object.assign(product, record);
      else state.products.push({ id: window.SchoolStock.nextId("products"), ...record });
      window.SchoolStock.save(); ui.toast(product ? "Product updated." : "Product added."); location.href = "products.html";
    });
  }
  const lowTable = document.getElementById("low-stock-table");
  if (lowTable) {
    const searchField = document.getElementById("low-stock-search"), filter = document.getElementById("low-stock-filter");
    const alerts = state.products.filter(item => item.stock <= item.minStock);
    document.getElementById("low-stock-stats").innerHTML = [
      ["◉", "Products to replenish", alerts.length],
      ["!", "Out of stock", alerts.filter(item => item.stock === 0).length],
      ["↗", "Low stock", alerts.filter(item => item.stock > 0).length],
      ["▦", "Total products", state.products.length]
    ].map(([icon, label, value]) => `<article class="stat-card"><span class="stat-icon">${icon}</span><div><p>${label}</p><strong>${value}</strong></div></article>`).join("");
    const draw = () => {
      const term = searchField.value.trim().toLowerCase();
      const filtered = alerts.filter(item => (!term || item.name.toLowerCase().includes(term)) && (filter.value === "all" || (filter.value === "out" ? item.stock === 0 : item.stock > 0)));
      lowTable.innerHTML = filtered.length ? filtered.map(item => `<tr><td><div class="product-name"><span class="product-symbol">▦</span><strong>${ui.escape(item.name)}</strong></div></td><td>${ui.escape(ui.category(item.categoryId))}</td><td>${item.stock}</td><td>${item.minStock}</td><td>${ui.badge(item)}</td><td><a class="action-link" href="stock-in.html">Replenish</a></td></tr>`).join("") : `<tr><td colspan="6" class="empty-state">No products match this view.</td></tr>`;
    };
    searchField.addEventListener("input", draw); filter.addEventListener("change", draw); draw();
  }
})();
